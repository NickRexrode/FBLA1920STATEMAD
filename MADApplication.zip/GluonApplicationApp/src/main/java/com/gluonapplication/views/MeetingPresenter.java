package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Meeting;
import com.gluonapplication.resources.Person;
import com.gluonapplication.GluonApplication;
import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// AUTHOR : Nick Rexrode
//This is the presenter class for the meetings tab

public class MeetingPresenter {

    public static MeetingPresenter ap = null;
    @FXML
    private View view;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private Text text;
    @FXML
    private VBox vBox;
    @FXML
    private Button iAmLoggedInButton;
    @FXML
    private AnchorPane viewMeeting;
    @FXML
    private AnchorPane notLoggedInPane;
    @FXML
    private AnchorPane listMeetings;
    @FXML
    private Button viewMeetingBackButton;
    @FXML
    private VBox viewMeetingvBox;
    @FXML
    private ScrollPane viewMeetingsScrollPane;
    private ArrayList<Meeting> meetingsList;
    @FXML
    private AnchorPane noChapterPane;
    public Meeting displayedMeeting = null;

    @FXML
    private void viewMeetingBackButtonClicked() {
        this.vBox.getChildren().clear();
        initialize();
    }

    @FXML
    private void iAmLoggedInButtonClicked() {
        initialize();
    }
    @FXML
    private Button inChapterButton;

    @FXML
    private void inChapterButtonClicked() {
        initialize();
    }
    @FXML
    private Button createNewMeetingButton;
    @FXML
    private AnchorPane createNewMeetingPane;
    @FXML
    private Button submitNewMeeting;
    @FXML
    private TextField nameField;
    @FXML
    private Text errText;
    @FXML
    private Button backButton;

    @FXML
    private void backButtonClicked() {
        initialize();
    }

    @FXML
    private void submitNewMeetingClicked() {

        if (this.nameField.getText().isEmpty()) {
            this.errText.setVisible(true);
            this.errText.setText("No name entered");
            return;
        }
        try {
            HttpClient client = new DefaultHttpClient();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/meetings/");
            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("chapter", ChapterPresenter.loggedInChapter.getUUID()));
            pairs.add(new BasicNameValuePair("name", this.nameField.getText()));
            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse response = client.execute(request);
            HttpEntity entity = response.getEntity();
            initialize();
        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        }
    }

    @FXML
    private void createNewMeetingClicked() {
        this.viewMeeting.setVisible(false);
        this.createNewMeetingPane.setVisible(true);
        noChapterPane.setVisible(false);
        notLoggedInPane.setVisible(false);
        listMeetings.setVisible(false);
    }
    // This class consists of many checks to avoid null errors.  If there is no logged in user or logged in chapter, the value will be null
    //The null checks basically prevent null errors by catching the problem before it can happen
    //By changing the values and recalling the initialize() method there will always be an update if something changes.
    public void initialize() {
        MeetingPresenter.ap = this;
        scrollPane.setContent(vBox);

        viewMeetingsScrollPane.setContent(viewMeetingvBox);
        viewMeetingvBox.getChildren().clear();
        noChapterPane.setVisible(false);
        this.createNewMeetingPane.setVisible(false);
        notLoggedInPane.setVisible(false);
        listMeetings.setVisible(false);
        viewMeeting.setVisible(false);

        this.errText.setVisible(false);

        view.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e
                        -> MobileApplication.getInstance().getDrawer().open()));
                appBar.setTitleText("Attendance");
            }
        });
        if (LoginPresenter.loggedInPerson == null) {
            listMeetings.setVisible(false);
            notLoggedInPane.setVisible(true);
            viewMeeting.setVisible(false);
            noChapterPane.setVisible(false);

            return;
          

        }
        if (ChapterPresenter.loggedInChapter == null) {
            listMeetings.setVisible(false);
            notLoggedInPane.setVisible(false);
            viewMeeting.setVisible(false);
            noChapterPane.setVisible(true);
            return;
         
        }

        if (ChapterPresenter.loggedInChapter != null) {

        }
        notLoggedInPane.setVisible(false);
        noChapterPane.setVisible(false);
        try {

            this.meetingsList = new ArrayList<>();

            listMeetings.setVisible(true);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(GluonApplication.IP_ADDRESS + "/chapters/" + ChapterPresenter.loggedInChapter.getUUID() + "/meetings");
            HttpResponse response = client.execute(request);
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(EntityUtils.toString(response.getEntity()));

            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) jsonArray.get(i);
                String meetingUUID = (String) jsonObj.get("uuid");
                String name = (String) jsonObj.get("name");
                Meeting meeting = new Meeting();

                meeting.setUuid(meetingUUID);
                meeting.setName(name);
                this.viewMeetingvBox.getChildren().add(new ListMeeting(meeting, this));

                meetingsList.add(meeting);

            }

        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
        }

    }
    private ArrayList<ListPerson> listPersonList = new ArrayList<>();

    public void displayMeeting(Meeting meeting) {
        listPersonList = new ArrayList<>();
        displayedMeeting = meeting;
        try {
            listMeetings.setVisible(false);
            notLoggedInPane.setVisible(false);
            viewMeeting.setVisible(true);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(GluonApplication.IP_ADDRESS + "/meetings/" + meeting.getUuid());

            HttpResponse response = client.execute(request);
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(EntityUtils.toString(response.getEntity()));

            if (!jsonArray.isEmpty()) {

                vBox.getChildren().removeAll();

                for (int i = 0; i < jsonArray.size(); i++) {
                    HttpGet personRequest = new HttpGet(GluonApplication.IP_ADDRESS + "/people/" + ((JSONObject) jsonArray.get(i)).get("uuidPerson"));
                    HttpResponse personResponse = client.execute(personRequest);

                    JSONObject jsonObj = (JSONObject) ((JSONArray) parser.parse(EntityUtils.toString(personResponse.getEntity()))).get(0);

                    String firstname = (String) jsonObj.get("firstname");
                    String lastname = (String) jsonObj.get("lastname");
                    int grade = Integer.valueOf(String.valueOf(jsonObj.get("grade")));
                    String uuid = (String) jsonObj.get("uuid");
                    Person p = new Person(firstname, lastname, grade, uuid);

                    int a = Integer.parseInt(String.valueOf(((JSONObject) jsonArray.get(i)).get("attendance")));
                    ListPerson lp = new ListPerson(p, this);

                    if (a == 0) {
                        lp.setAbsent();
                    }
                    if (a == 1) {
                        lp.setPresent();
                    }
                    listPersonList.add(lp);
                    vBox.getChildren().add(lp);

                }

            }

        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (org.apache.http.ParseException | ParseException ex) {
            ErrorManager.reportError("ParseException");
        }

    }

    public View getView() {
        try {
            View view1 = FXMLLoader.load(MeetingPresenter.class.getResource("attendence.fxml"));
            return view1;
        } catch (IOException e) {

            ErrorManager.reportError("IOException");
            return new View();
        }
    }
}
