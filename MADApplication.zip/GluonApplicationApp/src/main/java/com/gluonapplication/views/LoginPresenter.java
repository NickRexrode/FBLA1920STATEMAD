package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Person;
import com.gluonapplication.GluonApplication;
import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
//This class represents the login page.  
public class LoginPresenter {

    public static Person loggedInPerson = null;
    @FXML
    private View view;
    @FXML
    private Button createAccountButton;
    @FXML
    private Button logInButton;
    @FXML
    private TextField firstNameTextBox;
    @FXML
    private TextField lastNameTextBox;
    @FXML
    private TextField passwordTextBox;
    @FXML
    private StackPane loginStackPane;
    @FXML
    private AnchorPane loggedInPane;
    @FXML
    private AnchorPane logInPane;
    @FXML
    private Text loggedInNameText;
    @FXML
    private Button logOutButton;
    @FXML
    private Text errorText;
    @FXML
    private Button createAccountBackButton;
    @FXML
    private AnchorPane createAnAccountPane;
    @FXML
    private TextField createAccountFirstName;
    @FXML
    private TextField createAccountLastName;
    @FXML
    private TextField createAccountGrade;
    @FXML
    private PasswordField createAccountPassword;
    @FXML
    private Button createAccountSubmitButton;
@FXML private Text createAccountErrorText;
    @FXML
    private void createAccountSubmitButtonClicked() {
    
        if (this.createAccountFirstName.getText().isEmpty() || 
            this.createAccountLastName.getText().isEmpty() ||
            this.createAccountPassword.getText().isEmpty()||
            this.createAccountGrade.getText().isEmpty()) {
            
            this.createAccountErrorText.setVisible(true);
            return;
        }
        try {
            HttpClient client = new DefaultHttpClient();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/people/");

            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("firstname", createAccountFirstName.getText()));
            pairs.add(new BasicNameValuePair("lastname", createAccountLastName.getText()));
            pairs.add(new BasicNameValuePair("password", createAccountPassword.getText()));
            pairs.add(new BasicNameValuePair("grade", createAccountGrade.getText()));

            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse resp = client.execute(request);
            HttpEntity entity = resp.getEntity();
            if (resp.getStatusLine().getStatusCode() == 200) {
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(EntityUtils.toString(entity));
                java.lang.String uuid = "" + (String) json.get("uuid");

                java.lang.String firstname = "" + (String) json.get("firstname");
                java.lang.String lastname = "" + (String) json.get("lastname");
                int grade = (int) Integer.parseInt(String.valueOf(json.get("grade")));

                Person p = new Person(firstname, lastname, grade, uuid);
                LoginPresenter.loggedInPerson = p;
                initialize();
            }

        } catch (IOException | org.apache.http.ParseException ex) {
            ErrorManager.reportError("IOException");
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
        }
    }

    @FXML
    private void createAccountButtonClicked() {
        
        this.createAccountFirstName.setText("");
        this.createAccountLastName.setText("");
        this.createAccountPassword.setText("");
        this.createAccountGrade.setText("");
        createAccountErrorText.setVisible(false);
        loggedInPane.setVisible(false);
        logInPane.setVisible(false);
        createAnAccountPane.setVisible(true);
    }

    @FXML
    private void logOutButtonClicked() {
        LoginPresenter.loggedInPerson = null;
        //ChapterPresenter.loggedInChapter = null;
        
        
        this.firstNameTextBox.setText("");
        this.lastNameTextBox.setText("");
        this.passwordTextBox.setText("");
        
        if (MeetingPresenter.ap ==null) {
            
        } else {
            MeetingPresenter.ap.initialize();
        }
        if (ChapterPresenter.cp == null) {

        } else {
            ChapterPresenter.cp.initialize();
        }

        initialize();
    }
// The initialize() method again uses many checks to ensure it displays the right page.  Everytime it is called it reacts with new data.
    public void initialize() {
       
        errorText.setVisible(false);
        Person p = null;
    
        if (LoginPresenter.loggedInPerson == null) {
       
            loggedInPane.setVisible(false);
            logInPane.setVisible(true);
            createAnAccountPane.setVisible(false);
        } else {
            loggedInPane.setVisible(true);
            logInPane.setVisible(false);
            createAnAccountPane.setVisible(false);
            loggedInNameText.setText(LoginPresenter.loggedInPerson.firstname + " " + LoginPresenter.loggedInPerson.lastname);

        }
        view.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> MobileApplication.getInstance().getDrawer().open()));
                appBar.setTitleText("Login");

            }
        });
    }

    @FXML
    private void createAccountBackButtonClicked() {
        initialize();
    }

    @FXML
    public void logInButtonClicked() {
        Person p;
        if (firstNameTextBox.getText().isEmpty() ||this.lastNameTextBox.getText().isEmpty() || this.passwordTextBox.getText().isEmpty()) {
            this.errorText.setVisible(true);
        }
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/logins/");

            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("firstname", firstNameTextBox.getText()));
            pairs.add(new BasicNameValuePair("lastname", lastNameTextBox.getText()));
            pairs.add(new BasicNameValuePair("password", passwordTextBox.getText()));

            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse resp = client.execute(request);
            if (resp.getStatusLine().getStatusCode() == 200) {
                HttpEntity entity = resp.getEntity();

                JSONParser parser = new JSONParser();
                JSONArray jsonA = (JSONArray) parser.parse(EntityUtils.toString(entity));
                JSONObject json = (JSONObject) jsonA.get(0);
                java.lang.String uuid = (String) json.get("uuid");

                java.lang.String firstname = (String) json.get("firstname");
                java.lang.String lastname = (String) json.get("lastname");
                int grade = (int) Integer.parseInt(String.valueOf(json.get("grade")));

                p = new Person(firstname, lastname, grade, uuid);
                LoginPresenter.loggedInPerson = p;
               
                if (MeetingPresenter.ap ==null) {
                    
                } else {
                    MeetingPresenter.ap.initialize();
                }
                if (ChapterPresenter.cp == null) {

                } else {
                    ChapterPresenter.cp.initialize();
                }
                initialize();
            } else {
                HttpEntity en = resp.getEntity();
                
                errorText.setVisible(true);
            }

        } catch (UnsupportedEncodingException ex) {
           ErrorManager.reportError("UnsupportedEncodingexception");
            p = null;
            LoginPresenter.loggedInPerson = p;
            initialize();
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
            p = null;
            LoginPresenter.loggedInPerson = p;
            initialize();
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
            p = null;
            LoginPresenter.loggedInPerson = p;
            initialize();
        }
    }

    public View getView() {
        try {
            View view1 = FXMLLoader.load(LoginPresenter.class.getResource("login.fxml"));
            return view1;
        } catch (IOException e) {
          
            ErrorManager.reportError("IOException");
            return new View();
        }
    }

}
