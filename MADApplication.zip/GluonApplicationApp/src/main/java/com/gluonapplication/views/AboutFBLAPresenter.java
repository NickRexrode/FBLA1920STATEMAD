/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.web.WebView;

/**
 *
 * @author Nick
 */
//ABout fbla presenter.  The webPane and aboutPane get swapped when the appropriate buttons clicked
public class AboutFBLAPresenter {
    @FXML private Button joinFBLAButton;
    @FXML private Button FBLACalendarButton;
    @FXML private Button FBLAWebsiteButton;
    @FXML private Button qAndAButton;
    @FXML private Button contactFBLAButton;
    @FXML private ImageView facebookIconButton;
    @FXML private ImageView snapchatIconButton;
    @FXML private ImageView instagramIconButton;
    @FXML private ImageView twitterIconButton;
    
    @FXML private WebView webView;
    @FXML private Button exitButton;
    @FXML private View view;
    @FXML private AnchorPane webPane;
    @FXML private AnchorPane aboutPane;
    public void initialize() {
        webPane.setVisible(false);
        aboutPane.setVisible(true);
        view.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> 
                        MobileApplication.getInstance().getDrawer().open()));
                appBar.setTitleText("Primary");
            }
        });
    }

    public View getView() {
        try {
            View view1 = FXMLLoader.load(ChapterPresenter.class.getResource("aboutFBLA.fxml"));
            return view1;
        } catch (IOException e) {
            ErrorManager.reportError("IOException");
            return new View();
        }
    }
    @FXML private void snapchatIconClicked() {
        //https://www.snapchat.com/add/fbla_pbl
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.snapchat.com/add/fbla_pbl");
    }
    @FXML private void instagramIconClicked() {
        //http://instagram.com/fbla_pbl
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("http://instagram.com/fbla_pbl");
    }
    @FXML private void twitterIconClicked() {
        //https://twitter.com/FBLA_National
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://twitter.com/FBLA_National");
    }
    @FXML private void facebookIconClicked() {
        //https://www.facebook.com/FutureBusinessLeaders/
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.facebook.com/FutureBusinessLeaders/");
    }
    @FXML private void joinFBLAButtonClicked() {
        
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org/chapter-organization-packet/");
        
    }
    @FXML private void FBLACalendarButtonClicked() {
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org/fbla/programs/national/calendar/");
        
    }
    @FXML private void FBLAWebsiteButtonClicked() {
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org");
        
    }
    @FXML private void qAndAButtonClicked() {
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org/?s=faq#");
        
    }
    @FXML private void contactFBLAButtonClicked() {
        webPane.setVisible(true);
        aboutPane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org/contact/");
        
    }
    @FXML private void exitButtonClicked() {
        initialize();
        webView.getEngine().load("");
        
    }
}
