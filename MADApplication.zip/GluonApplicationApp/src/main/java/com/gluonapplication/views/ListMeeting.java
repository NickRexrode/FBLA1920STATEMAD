/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Meeting;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

/**
 *
 * @author Nick
 */
//This is the ListMeeting presenter
public class ListMeeting extends HBox{
    
    
    @FXML private Button viewMeetingButton;
    @FXML private Text meetingName;
    
    private Meeting meeting;
    private MeetingPresenter mp;
    @FXML private void viewMeetingButtonClicked() {
        mp.displayMeeting(this.meeting);
        
    }
    //MeetingPresenter is passed in as a parameter so the methods could be called.
    public ListMeeting(Meeting meeting, MeetingPresenter mp) {
        this.meeting = meeting;
        this.mp = mp;
        try {
            FXMLLoader loader1 = new FXMLLoader(getClass().getResource("listmeeting.fxml"));
            loader1.setController(this);
            loader1.setRoot(this);
            loader1.load();
            this.meetingName.setText(this.meeting.getName());
        } catch (IOException exc) {
ErrorManager.reportError("IOException");
        }
    }
    
    public void initialize() {
        
    }
    
}
