/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.web.WebView;

/**
 *
 * @author Nick
 */
//This is the presenter for the Denmark High School FBLA Chapter
public class LocalFBLAPresenter {

    @FXML
    private Button localCalendarButton;
    @FXML
    private Button EventsButton;
    @FXML
    private Button EventSignupButton;

    @FXML private View view;
    @FXML private AnchorPane webPane;
    @FXML private WebView webView;
    @FXML private Button exitButton;    
    @FXML private AnchorPane pane;
    @FXML private void exitButtonClicked() {
        this.pane.setVisible(true);
        this.webPane.setVisible(false);
    }
    
    @FXML private void localCalendarButtonClicked() {
        this.webPane.setVisible(true);
        this.pane.setVisible(false);
        webView.getEngine().load("https://dpi.wi.gov/sites/default/files/imce/fbla/pdf/Calendar/2019-2020_FBLA_Calendar_updated_2019_09_30.pdf");
        
    }
    @FXML private void EventsButtonClicked() {
        this.webPane.setVisible(true);
        this.pane.setVisible(false);
        webView.getEngine().load("https://www.fbla-pbl.org/fbla/competitive-events/");
    }
    @FXML private void EventSignupButtonClicked() {
        this.webPane.setVisible(true);
        this.pane.setVisible(false);
        webView.getEngine().load("http://wisconsinfbla.wufoo.com/forms/wi-fbla-statement-of-assurances-event-entry-form");
    }
    public void initialize() {
    this.pane.setVisible(true);
        this.webPane.setVisible(false);
        view.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e
                        -> MobileApplication.getInstance().getDrawer().open()));
                appBar.setTitleText("Attendance");
            }
        });
    }
    public View getView() {
        try {
            View view1 = FXMLLoader.load(LocalFBLAPresenter.class.getResource("localChapter.fxml"));
            return view1;
        } catch (IOException e) {
            
            return new View();
        }
    }

}
