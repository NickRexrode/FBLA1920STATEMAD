/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;


import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Person;
import com.gluonapplication.resources.Chapter;
import com.gluonapplication.GluonApplication;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

/**
 *
 * @author Nick
 */
//this is the fx:root for ListChapter.  When you are presented chapters to join, this is used to display each chapter.  They all have a join button unique to each other.
public class ListChapter extends HBox{
    @FXML private Text chapterName;
    @FXML private Button joinButton;
    private Chapter chapter;
    private ChapterPresenter cp;
    
    
    public ListChapter(Chapter chapter, ChapterPresenter cp) {
         try {
             this.chapter = chapter;
             this.cp = cp;
             
            FXMLLoader loader = new FXMLLoader(getClass().getResource("listchapter.fxml"));
            loader.setController(this);
            loader.setRoot(this);
            loader.load();
        } catch (IOException exc) {
            ErrorManager.reportError("IOException");
        }
        
        

    }
    
    public void initialize() {
              this.chapterName.setText(this.chapter.getSchoolName());
    }
    @FXML private void joinChapterButtonClicked() {
        try {
            Person p = LoginPresenter.loggedInPerson;
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost addToChapterTable = new HttpPost(GluonApplication.IP_ADDRESS+"/chapters/"+this.chapter.getUUID());
            
            List<NameValuePair> dataChapterTable = new ArrayList<NameValuePair>();
            dataChapterTable.add(new BasicNameValuePair("uuidPerson", ""+p.uuid));
            
            addToChapterTable.setEntity(new UrlEncodedFormEntity(dataChapterTable));
            HttpResponse resp = client.execute(addToChapterTable);
            HttpPost setPersonChapter = new HttpPost(GluonApplication.IP_ADDRESS+"/people/"+LoginPresenter.loggedInPerson.uuid+"/chapter/"+this.chapter.getUUID());
            HttpResponse setPersonChapterResp = client.execute(setPersonChapter);
            
            if (resp.getStatusLine().getStatusCode() != 200 || setPersonChapterResp.getStatusLine().getStatusCode() !=200) {
                //ERROR

            }
            ChapterPresenter.loggedInChapter = chapter;
            if (MeetingPresenter.ap != null) {
            MeetingPresenter.ap.initialize();
            }
            cp.reloadListButtonClicked();
            cp.initialize();
        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        }
    }
}
