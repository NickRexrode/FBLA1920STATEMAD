/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Person;
import com.gluonapplication.GluonApplication;
import com.gluonhq.charm.glisten.control.ToggleButtonGroup;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

/**
 *
 * @author Nick
 */
//This is the fx:root class for ListPerson.  This class is used for meeting attendence.
public class ListPerson extends HBox {
    
    @FXML private Text text;
    @FXML private ToggleButtonGroup toggleButtonGroup;
    @FXML public ToggleButton absentButton;
    @FXML public ToggleButton presentButton;
    
    private Person person;
    private MeetingPresenter ap;
    public void setAbsent(){
        this.presentButton.setSelected(false);
        this.absentButton.setSelected(true);
    }
    public void setPresent() {
        this.presentButton.setSelected(true);
        this.absentButton.setSelected(false);
    }
    public ListPerson(Person person, MeetingPresenter ap) {
         try {

            this.person = person;
            this.ap = ap;
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("listperson.fxml"));
            loader.setRoot(this);
            loader.setController(this);
            loader.load();
            this.text.setText(person.firstname); 

        } catch (IOException exc) {
            ErrorManager.reportError("IOException");
        }
        
        

    }
    public void sendHttpPut(int attendence) {
        try {
            HttpClient client = new DefaultHttpClient();
            HttpPut request = new HttpPut(GluonApplication.IP_ADDRESS + "/meetings/" + this.ap.displayedMeeting.getUuid());
          
            List<NameValuePair> pairs = new ArrayList<>();
            
            pairs.add(new BasicNameValuePair("uuidPerson", this.person.uuid));
            
            pairs.add(new BasicNameValuePair("attendance",""+ attendence));
            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse response = client.execute(request);
            HttpEntity entity = response.getEntity();
        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        }
    } 
    @FXML private void presentButtonClicked() {
        this.sendHttpPut(1);
    }
    @FXML private void absentButtonClicked() {
        this.sendHttpPut(0);
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
    
    
}
