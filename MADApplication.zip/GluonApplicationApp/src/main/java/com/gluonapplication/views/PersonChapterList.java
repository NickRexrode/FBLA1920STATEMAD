/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Person;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

/**
 *
 * @author Nick Rexrode
 */
public class PersonChapterList extends HBox {

    @FXML
    private Text text;
    private Person person;
    private ChapterPresenter cp;
    //This is the fx:root class for displaying members in their chapter
    //The ChapterPresetner is passed as an object so it can be accessed.
    public PersonChapterList(Person person, ChapterPresenter cp) {
        try {
            this.person = person;
            this.cp = cp;

            FXMLLoader loader = new FXMLLoader(getClass().getResource("personChapterList.fxml"));
            loader.setRoot(this);
            loader.setController(this);
            loader.load();
            this.text.setText(person.firstname);

        } catch (IOException exc) {
            ErrorManager.reportError("IOException");
        }

    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
