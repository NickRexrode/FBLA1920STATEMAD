/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.views;

import com.gluonapplication.resources.ErrorManager;
import com.gluonapplication.resources.Person;
import com.gluonapplication.resources.Chapter;
import com.gluonapplication.GluonApplication;
import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Nick
 */
//ChapterPresenter class manages the chapter pane..  Similar to the other Presenter classes.  The initialize() method is called to reinitialize it with fresh info
public class ChapterPresenter {

    @FXML
    private Button iAmLoggedInButton;

    @FXML
    private Button exitButton;
    @FXML
    private StackPane stackPane;
    @FXML
    private Button joinButton;
    @FXML
    private Button createButton;
    @FXML
    private AnchorPane noChapterPane;
    @FXML
    private ScrollPane chapterScrollPane;
    @FXML
    private VBox vBoxChaptersList;
    @FXML
    private View view;
    @FXML
    private AnchorPane createChapterPane;
    @FXML
    private TextField schoolNameTextField;
    @FXML
    private TextField chapterNameTextField;
    @FXML
    private AnchorPane currentChapterPane;
    @FXML
    private Text chapterNameText;
    @FXML
    private Button unenrollButton;
    @FXML
    private AnchorPane scrollAnchorPane;
    @FXML
    private Button listBackButton;
    @FXML
    private Button listCreateChapterRedirectButton;
    private JSONParser parser;
    @FXML
    private Button createChapterBack;

    @FXML
    private TextField gradeTextField;
    @FXML
    private TextField lastnameTextField;
    @FXML
    private TextField firstnameTextField;
    @FXML
    private Button submitNewMember;

    @FXML
    private Button newMemberBackButton;
    @FXML
    private ScrollPane displayListScrollPane;
    @FXML
    private VBox displayListvBox;
    @FXML
    private Button addMemberToChapterButton;
    @FXML
    private AnchorPane addMemberPane;
    @FXML
    private Button reloadListButton;
    public ArrayList<Chapter> chaptersList;
    @FXML
    private AnchorPane notLoggedInPane;
    public static Chapter loggedInChapter = null;
    public static ChapterPresenter cp = null;
    public void reloadListButtonClicked() {
        displayListvBox.getChildren().clear();
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(GluonApplication.IP_ADDRESS + "/chapters/" + ChapterPresenter.loggedInChapter.getUUID() + "/people");
           
            HttpResponse response = client.execute(request);
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(EntityUtils.toString(response.getEntity()));
          

            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObj = (JSONObject) jsonArray.get(i);
                HttpGet loopRequest = new HttpGet(GluonApplication.IP_ADDRESS + "/people/" + jsonObj.get("uuidPerson"));
             
                HttpResponse loopResponse = client.execute(loopRequest);

                JSONArray loopArray = (JSONArray) parser.parse(EntityUtils.toString(loopResponse.getEntity()));
                JSONObject loopObject = (JSONObject) loopArray.get(0);
                String firstname = (String) loopObject.get("firstname");
                String lastname = (String) loopObject.get("lastname");
                int grade = Integer.valueOf(String.valueOf(loopObject.get("grade")));
                String uuid = (String) loopObject.get("uuid");
                Person p = new Person(firstname, lastname, grade, uuid);
                displayListvBox.getChildren().add(new PersonChapterList(p, cp));
            }

        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (org.apache.http.ParseException ex) {
           ErrorManager.reportError("ParseException");
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
        }
    }

    @FXML
    private void newMemberBackButtonClicked() {
        initialize();
    }

    @FXML
    private void iAmLoggedInButtonClicked() {
        initialize();
    }
@FXML private Text addMemberErrorText;
    @FXML
    private void submitNewMemberClicked() {
        if (this.firstnameTextField.getText().isEmpty() || this.lastnameTextField.getText().isEmpty() || this.gradeTextField.getText().isEmpty()) {
            this.addMemberErrorText.setVisible(true);
            return;
        }
        try {
            //TODO: send POST
            HttpClient client = new DefaultHttpClient();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/people");
            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("firstname", firstnameTextField.getText()));
            pairs.add(new BasicNameValuePair("lastname", lastnameTextField.getText()));
            pairs.add(new BasicNameValuePair("grade", gradeTextField.getText()));

            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse response = client.execute(request);
            HttpEntity entity = response.getEntity();
            JSONParser parser = new JSONParser();
            JSONObject jsonObj = (JSONObject) parser.parse(EntityUtils.toString(entity));
            String uuid = (String) jsonObj.get("uuid");
            //Add to chapter
            HttpClient client1 = new DefaultHttpClient();
            HttpPost request1 = new HttpPost(GluonApplication.IP_ADDRESS + "/chapters/" + ChapterPresenter.loggedInChapter.getUUID());
            List<NameValuePair> pairs1 = new ArrayList<>();
            pairs1.add(new BasicNameValuePair("uuidPerson", uuid));
            request1.setEntity(new UrlEncodedFormEntity(pairs1));
            HttpResponse response1 = client1.execute(request1);
            if (response1.getStatusLine().getStatusCode() == 200 && response.getStatusLine().getStatusCode() == 200) {
                reloadListButtonClicked();
                initialize();
            }
        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
        }

    }

    @FXML
    private void createChapterBackClicked() {
        noChapterPane.setVisible(true);
        errorText.setVisible(false);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(false);
        currentChapterPane.setVisible(false);
    }

    @FXML
    private void unenrollButtonClicked() {
        try {

            HttpClient client = new DefaultHttpClient();
            HttpDelete request = new HttpDelete(GluonApplication.IP_ADDRESS + "/people/" + LoginPresenter.loggedInPerson.uuid);

            HttpResponse resp = client.execute(request);

            HttpDelete request2 = new HttpDelete(GluonApplication.IP_ADDRESS + "/chapters/" + ChapterPresenter.loggedInChapter.getUUID() + "/" + LoginPresenter.loggedInPerson.uuid);
           
            HttpClient client1 = new DefaultHttpClient();
            HttpResponse resp1 = client1.execute(request2);
            if (resp.getStatusLine().getStatusCode() == 200) {
                ChapterPresenter.loggedInChapter = null;
                vBoxChaptersList.getChildren().clear();
                chaptersList = new ArrayList<>();
                if (MeetingPresenter.ap != null) {
                MeetingPresenter.ap.initialize();
                }
                initialize();
            }
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        }
    }

    @FXML
    private void listBackButtonClicked() {
        noChapterPane.setVisible(true);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(false);
        currentChapterPane.setVisible(false);
        
        vBoxChaptersList.getChildren().clear();
        chaptersList = new ArrayList<>();
    }

    @FXML
    private void listCreateChapterRedirectButtonClicked() {
        noChapterPane.setVisible(false);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(true);
        currentChapterPane.setVisible(false);
        vBoxChaptersList.getChildren().clear();
        chaptersList = new ArrayList<>();
    }

    @FXML
    private void addMemberToChapterButtonClicked() {
        noChapterPane.setVisible(false);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(false);
        currentChapterPane.setVisible(false);
        addMemberPane.setVisible(true);
    }
@FXML private Text errorText;
    public void initialize() {
        ChapterPresenter.cp = this;
        displayListScrollPane.setContent(displayListvBox);
        chapterScrollPane.setContent(vBoxChaptersList);
        this.addMemberErrorText.setVisible(false);
        this.errorText.setVisible(false);
        view.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e
                        -> MobileApplication.getInstance().getDrawer().open()));

                appBar.setTitleText("Primary");

            }

        });
        noChapterPane.setVisible(false);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(false);
        addMemberPane.setVisible(false);
        currentChapterPane.setVisible(false);
        notLoggedInPane.setVisible(false);
        if (LoginPresenter.loggedInPerson == null) {
            notLoggedInPane.setVisible(true);
            return;
        }
        if (ChapterPresenter.loggedInChapter == null) {
           
            try {
              
                HttpClient client = new DefaultHttpClient();
                //:uuid/chapter
                HttpGet request = new HttpGet(GluonApplication.IP_ADDRESS + "/people/" + LoginPresenter.loggedInPerson.uuid + "/chapter");
                
                HttpResponse response = client.execute(request);
      
                HttpEntity entity = response.getEntity();
                JSONParser parser1 = new JSONParser();
                JSONArray jsonArray = (JSONArray) parser1.parse(EntityUtils.toString(response.getEntity()));
                JSONObject jsonObj = (JSONObject) jsonArray.get(0);
             
                String chapterName = (String) jsonObj.get("chapter");
                if (chapterName.equals("")) {
                    //Load no chapter
               
                    noChapterPane.setVisible(true);
                    scrollAnchorPane.setVisible(false);
                    createChapterPane.setVisible(false);
                    addMemberPane.setVisible(false);
                    currentChapterPane.setVisible(false);
              
                    return;
                }
                String chapterUUID = (String) jsonObj.get("chapter");
                HttpGet chapterRequest = new HttpGet(GluonApplication.IP_ADDRESS + "/chapters/" + chapterUUID);
                HttpResponse chapterDataResponse = client.execute(chapterRequest);
                JSONParser parser2 = new JSONParser();
                JSONArray jsonArrayChapter = (JSONArray) parser2.parse(EntityUtils.toString(chapterDataResponse.getEntity()));
                JSONObject jsonObjChapter = (JSONObject) jsonArrayChapter.get(0);
          
                ChapterPresenter.loggedInChapter = new Chapter((String) jsonObjChapter.get("school"), chapterUUID);
                chapterNameText.setText((String)jsonObjChapter.get("school"));
           
                initialize();
            } catch (ParseException | IOException | org.apache.http.ParseException ex) {
                ErrorManager.reportError(ex.getClass().getName());
            }

        } else {
     
            noChapterPane.setVisible(false);
            scrollAnchorPane.setVisible(false);
            createChapterPane.setVisible(false);
            addMemberPane.setVisible(false);
            currentChapterPane.setVisible(true);
            reloadListButtonClicked();
        }

    }

    @FXML
    private void joinChapterButtonClicked() {
        try {
            vBoxChaptersList.setVisible(true);
            noChapterPane.setVisible(false);
            createChapterPane.setVisible(false);
            scrollAnchorPane.setVisible(true);
            chaptersList = new ArrayList<>();

            CloseableHttpClient httpclient = HttpClients.createDefault();

            //Creating a HttpGet object
            HttpGet httpget = new HttpGet(GluonApplication.IP_ADDRESS + "/chapters");

         

            //Executing the Get request
            HttpResponse httpresponse = httpclient.execute(httpget);

            HttpEntity entity = httpresponse.getEntity();

            //Printing the status line

            JSONParser parser = new JSONParser();
            JSONArray jsonA = (JSONArray) parser.parse(EntityUtils.toString(entity));
            if (!jsonA.isEmpty()) {
                chaptersList = new ArrayList<>();
                vBoxChaptersList.getChildren().removeAll();
                chaptersList = new ArrayList<>();
                for (int i = 0; i < jsonA.size(); i++) {
                    JSONObject jsonObj = (JSONObject) jsonA.get(i);
                    String school = (String) jsonObj.get("school");
                    String uuid = (String) jsonObj.get("uuid");
                    chaptersList.add(new Chapter(school, uuid));
                    vBoxChaptersList.getChildren().add(new ListChapter(chaptersList.get(i), this));
         
                }
            }

        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (ParseException ex) {
            ErrorManager.reportError("ParseException");
        }
    }

    @FXML
    private void createChapterButtonClicked() {
        noChapterPane.setVisible(false);
        scrollAnchorPane.setVisible(false);
        createChapterPane.setVisible(true);
    }

    @FXML
    private void submitChapterButtonClicked() {
        if (this.schoolNameTextField.getText().isEmpty()) {
            this.errorText.setVisible(true);
     
            return;
        }
        try {
            //SEND POST REQUEST
            HttpClient client = new DefaultHttpClient();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/chapters");

      

            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("school", schoolNameTextField.getText()));
            pairs.add(new BasicNameValuePair("userUUID", LoginPresenter.loggedInPerson.uuid));

            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse resp = client.execute(request);
            HttpEntity entity = resp.getEntity();

            JSONParser parser = new JSONParser();
        
            JSONObject obj = (JSONObject) parser.parse(EntityUtils.toString(entity));
            ChapterPresenter.loggedInChapter = new Chapter(schoolNameTextField.getText(), (String) obj.get("chapterUUID"));
            this.initialize();

        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        } catch (org.apache.http.ParseException ex) {
            ErrorManager.reportError("ParseExcaption");
        } catch (ParseException ex) {
           ErrorManager.reportError("ParseException");
        }

    }

    public View getView() {

        try {
            View view1 = FXMLLoader.load(ChapterPresenter.class.getResource("chapter.fxml"));
            return view1;
        } catch (IOException e) {
ErrorManager.reportError("IOException");
            return new View();
        }
    }

}
