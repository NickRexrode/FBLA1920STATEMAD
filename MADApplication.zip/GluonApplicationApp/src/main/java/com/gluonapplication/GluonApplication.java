package com.gluonapplication;

import com.gluonapplication.views.AboutFBLAPresenter;
import com.gluonapplication.views.MeetingPresenter;
import com.gluonapplication.views.ChapterPresenter;
import com.gluonapplication.views.LocalFBLAPresenter;
import com.gluonapplication.views.LoginPresenter;
import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.visual.Swatch;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class GluonApplication extends MobileApplication {
    public static final String IP_ADDRESS = "http://184.97.88.213:3000";
    public static final String MEETINGS_VIEW = "Meetings View";
    public static final String CHAPTER_VIEW = "Chapter View";
    public static final String ABOUT_FBLA_VIEW = "About FBLA View";
    public static final String LOCAL_CHAPTER_VIEW = "Local Chapter View";
    
    @Override
    public void init() {
        //LoginPresenter.loggedInPerson = null;
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("javafx.version"));
//        
        
        addViewFactory(HOME_VIEW, () -> new LoginPresenter().getView());
        addViewFactory(MEETINGS_VIEW, () -> new MeetingPresenter().getView());
        addViewFactory(CHAPTER_VIEW, () -> new ChapterPresenter().getView());
        addViewFactory(ABOUT_FBLA_VIEW, () -> new AboutFBLAPresenter().getView());
        addViewFactory(LOCAL_CHAPTER_VIEW, () -> new LocalFBLAPresenter().getView());
        
        DrawerManager.buildDrawer(this);
    }

    @Override
    public void postInit(Scene scene) {
        Swatch.BLUE.assignTo(scene);

        scene.getStylesheets().add(GluonApplication.class.getResource("style.css").toExternalForm());
        ((Stage) scene.getWindow()).getIcons().add(new Image(GluonApplication.class.getResourceAsStream("/icon.png")));
    }
}
