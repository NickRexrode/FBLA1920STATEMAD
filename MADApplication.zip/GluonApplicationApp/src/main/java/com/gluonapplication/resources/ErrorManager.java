/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.resources;

import com.gluonapplication.GluonApplication;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

/**
 *
 * @author Nick
 */
//Error manager / Bug reported class.  All bugs are reported
public class ErrorManager {
    public static void reportError(String error) {
        try {
            System.out.println(error);
            HttpClient client = new DefaultHttpClient();
            HttpPost request = new HttpPost(GluonApplication.IP_ADDRESS + "/errors");
            List<NameValuePair> pairs = new ArrayList<NameValuePair>();
            pairs.add(new BasicNameValuePair("error", error));

            request.setEntity(new UrlEncodedFormEntity(pairs));
            HttpResponse resp = client.execute(request);
        } catch (UnsupportedEncodingException ex) {
            ErrorManager.reportError("UnsupportedEncodingException");
        } catch (IOException ex) {
            ErrorManager.reportError("IOException");
        }
    }

}
