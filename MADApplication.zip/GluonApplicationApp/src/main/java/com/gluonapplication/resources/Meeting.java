/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.resources;

import java.util.ArrayList;

/**
 *
 * @author Nick
 */
//This is the meeting structure class

public class Meeting {
    private ArrayList<Person> people;
    private ArrayList<Integer> attendence;
    private String name;
    private String uuid;
    @Override
    public String toString() {
        return name + " "+ uuid;
    }
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    

    public ArrayList<Person> getPeople() {
        return people;
    }

    public void setPeople(ArrayList<Person> people) {
        this.people = people;
    }

    public ArrayList<Integer> getAttendence() {
        return attendence;
    }

    public void setAttendence(ArrayList<Integer> attendence) {
        this.attendence = attendence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
