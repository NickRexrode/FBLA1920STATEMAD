/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.resources;

/**
 *
 * @author Nick
 */

//This is the chapter class. 
public class Chapter {
    private String uuid;
    private String school;
    
    public Chapter(String school, String uuid) {
        this.school = school;
        this.uuid = uuid;
    }
    public String getSchoolName() {
        return this.school;
    }
    public String getUUID() {
        return this.uuid;
    }
    public String toString() {
        return this.uuid + " "+ this.school;
    }
}
