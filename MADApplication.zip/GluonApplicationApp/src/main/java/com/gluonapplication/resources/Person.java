/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gluonapplication.resources;

/**
 *
 * @author Nick Rexrode
 */
//This is the person Object.  It is used for every person in the system
public class Person {
    public String firstname;
    public String lastname;
    public int grade;
    public String uuid;
    
    public Person(String firstname, String lastname, int grade, String uuid) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.grade = grade;
        this.uuid = uuid;
        
    }
    @Override
    public String toString() {
        return ""+this.firstname + " "+ this.lastname + " "+ this.grade + " "+ this.uuid;
    }
    public boolean equals(Person p) {
        boolean r = true;
        if (!this.firstname.equals(p.firstname)) {
            r = false;
        }
        if (!this.lastname.equals(p.lastname)) {
            r = false;
        }
        if (this.grade == p.grade) {
            r = false;
        }
        if (this.uuid.equals(p.uuid)) {
            r = false;
        }
        return r;
    }
    
}
