package com.gluonapplication;

import static com.gluonapplication.GluonApplication.ABOUT_FBLA_VIEW;
import static com.gluonapplication.GluonApplication.CHAPTER_VIEW;
import static com.gluonapplication.GluonApplication.LOCAL_CHAPTER_VIEW;
import static com.gluonapplication.GluonApplication.MEETINGS_VIEW;
import com.gluonapplication.views.AboutFBLAPresenter;
import com.gluonapplication.views.MeetingPresenter;
import com.gluonapplication.views.ChapterPresenter;
import com.gluonapplication.views.LoginPresenter;
import com.gluonhq.charm.down.Platform;
import com.gluonhq.charm.down.Services;
import com.gluonhq.charm.down.plugins.LifecycleService;
import com.gluonhq.charm.glisten.application.MobileApplication;
import static com.gluonhq.charm.glisten.application.MobileApplication.HOME_VIEW;
import com.gluonhq.charm.glisten.application.ViewStackPolicy;
import com.gluonhq.charm.glisten.control.Avatar;
import com.gluonhq.charm.glisten.control.NavigationDrawer;
import com.gluonhq.charm.glisten.control.NavigationDrawer.Item;
import com.gluonhq.charm.glisten.control.NavigationDrawer.ViewItem;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
//import static com.gluonapplication.GluonApplication.CHAPTER_VIEW;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;

public class DrawerManager {

    public static ViewItem homeItem = null;
    public static ViewItem meetingItem = null;
    public static ViewItem chapterItem = null;
    public static ViewItem aboutFBLAItem = null;
    public static ViewItem localChapterItem = null;
    public static void buildDrawer(MobileApplication app) {
        NavigationDrawer drawer = app.getDrawer();
        Avatar avatar =new Avatar(51, new Image(DrawerManager.class.getResourceAsStream("/icon.png")));
        NavigationDrawer.Header header = new NavigationDrawer.Header("Chapter Management",
                "By: Nick Rexrode",
                avatar
        );
        drawer.setHeader(header);

        DrawerManager.homeItem = new ViewItem("Home", MaterialDesignIcon.HOME.graphic(), HOME_VIEW, ViewStackPolicy.SKIP);
        DrawerManager.meetingItem = new ViewItem("Meetings", MaterialDesignIcon.DASHBOARD.graphic(), MEETINGS_VIEW);
        DrawerManager.chapterItem = new ViewItem("Chapter", MaterialDesignIcon.DASHBOARD.graphic(), CHAPTER_VIEW);
        DrawerManager.aboutFBLAItem = new ViewItem("About FBLA", MaterialDesignIcon.DASHBOARD.graphic(), ABOUT_FBLA_VIEW);
        DrawerManager.localChapterItem = new ViewItem("Local Chapter", MaterialDesignIcon.DASHBOARD.graphic(), LOCAL_CHAPTER_VIEW);

        drawer.getItems().addAll(homeItem, meetingItem, chapterItem, aboutFBLAItem, localChapterItem);

        
    }
}
